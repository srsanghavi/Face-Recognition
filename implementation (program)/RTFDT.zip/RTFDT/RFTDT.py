# USAGE
# python detecttracktrial.py
# Author: Shashwat Sanghavi, Anokhi Gandhi, Sohum Shah, Kashyap Patel
# Team: DOBA

# In this code- we are using viola jones inside camshift algorithm. After aplying camshift for CONSTANT number of frames we apply viola Jones algorithm inoder to find face and then this/these face/faces will be detected for subsequent CONSTANT number of faces.

# Importing essential libraries
import numpy as np
import argparse
import cv2
from facedetect.facedetector import FaceDetector
scaleResize=5
framecheck=29
frame = None # frame is used for storing each frame of the video while performing all operations
inputMode = False # This flag is used as a lock for swapping between two algorithms
tl=[] # holds the cordinates of he detected face
br=[] # holds the cordinates of he detected face

# Function for tracking the object (CAMSHIFT)
def trackRoi(roiBox,roiHist,termination):
	global frame, inputMode
	hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
	backProj = cv2.calcBackProject([hsv], [0], roiHist, [0, 180], 1)
	(r, roiBox) = cv2.CamShift(backProj, roiBox, termination)
	if r==((0.0, 0.0), (0.0, 0.0), 0.0):
		roiBox=[]
		return
	pts = np.int0(cv2.cv.BoxPoints(r))
	cv2.polylines(frame, [pts], True, (0,255, 255), 6)
                
# Main function
def main():
        global frame, inputMode		
        camera = cv2.VideoCapture('Video3.mp4') #input video
        cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
	count=0; #intitializing counter for counting number of frames which will be reset when viola jones face detection algorithm is called
        termination = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1)
        roiBox = [] #roiBox saves the are of interest which will be face in our case and it will be used in CAMSHIFT algorithm

	#infinte loop
        while True:
                count=count+1	# count used for calculating frames       
                (grabbed, frame) = camera.read() # grab the next frame
                if not grabbed: # if frame is not grabbed, exit the loop and exit the code
                        break
		if roiBox is not None:	# If region of interest is decided, the call CAMSHIFT function
			l=len(roiBox)
			for k in xrange(0,l): # Track all detected faces
                		trackRoi(roiBox[k],roiHist,termination)

                cv2.imshow("frame", frame) #show the current frame
                key = cv2.waitKey(1) & 0xFF

                if (count==framecheck):	# after every 15 frames check for the face
			faceRects=() # initialize the list which cotains all the faces
			while (faceRects==()):  #until face is not detected, keep detecting faces in subsequent frames
				cv2.imshow("frame", frame)	
		                key = cv2.waitKey(1) & 0xFF
		                h,l,c=frame.shape
				th = cv2.resize(frame,(l/scaleResize,h/scaleResize), interpolation = cv2.INTER_CUBIC)	# resize the frame to 256 * 156 size
				gray = cv2.cvtColor(th, cv2.COLOR_BGR2GRAY)	# convert it to grayscale
	    			fd = FaceDetector("cascades/haarcascade_frontalface_default.xml")	# loading Haar features
				faceRects = fd.detect(gray, scaleFactor = 1.1, minNeighbors = 5,minSize = (15,15))	# call facedetection function which return coordinates of faces
				(grabbed, frame) = camera.read()	# read next frame

                        inputMode = True
                        roiBox=[]
                        orig = frame.copy()

			# set ROI for each face
			for k in faceRects:
		                x=scaleResize*(k[0]+(k[2])/2-7)
				y=scaleResize*(k[1]+(k[3])/2-17)
				x1=scaleResize*(k[0]+k[2]/2-2)
				y1=scaleResize*(k[1]+k[3]/2-12)
				#x=scaleResize*(k[0])
				#y=scaleResize*(k[1])
				#x1=scaleResize*(k[0]+k[2])
				#y1=scaleResize*(k[1]+k[3])
				roi = orig[y:y1, x:x1]
				#cv2.imshow("",roi)
		                roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
		                roiHist = cv2.calcHist([roi], [0], None, [16], [0, 180])
		                roiHist = cv2.normalize(roiHist, roiHist, 0, 255, cv2.NORM_MINMAX)
		                box = (x, y, x1, y1)
		                roiBox.append(box)
			count=0

                elif key == ord("q"):	#q key will exit the program
                        break
                elif key == ord("f"): # f key will fast forward
			for a in xrange(90):
				(grabbed, frame) = camera.read()
			cv2.imshow("frame", frame)
	                key = cv2.waitKey(1) & 0xFF

        camera.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
        main()
